from PyQt5.QtCore import Qt
from loginman import *
import sys
import requests
from PyQt5.QtGui import QPixmap
from PyQt5 import QtCore, QtGui, QtWidgets
import tkinter.messagebox as messagebox
from PyQt5.QtWidgets import QDialog
from PyQt5.QtGui import *
# UI设计，工具开源 by crazy

class mains(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        self.mian_ui = main()
        self.mian_ui.setupUi(self)

class card(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.setWindowIcon(QIcon('222.png'))
        Form.setFixedSize(485,337)
        Form.resize(485, 337)
        Form.setWindowFlag(Qt.FramelessWindowHint)
        self.background = QtWidgets.QLabel(Form)
        self.background.setGeometry(QtCore.QRect(-20, -30, 541, 371))
        self.background.setText("")
        self.background.setPixmap(QPixmap('2.png'))
        self.background.setObjectName("background")
        self.account = QtWidgets.QLabel(Form)
        self.account.setGeometry(QtCore.QRect(130, 110, 51, 21))
        font = QtGui.QFont()
        font.setPointSize(13)
        font.setBold(True)
        font.setWeight(75)
        self.account.setFont(font)
        self.account.setObjectName("account")
        self.interface1 = QtWidgets.QLabel(Form)
        self.interface1.setGeometry(QtCore.QRect(180, 20, 141, 31))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.interface1.setFont(font)
        self.interface1.setObjectName("interface1")
        self.account_edit = QtWidgets.QLineEdit(Form)
        self.account_edit.setGeometry(QtCore.QRect(190, 100, 160, 40))
        self.account_edit.setObjectName("account_edit")
        self.pushButton_password = QtWidgets.QPushButton(Form)
        self.pushButton_password.setGeometry(QtCore.QRect(210, 160, 91, 40))
        self.pushButton_password.clicked.connect(self.text)
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_password.setFont(font)
        self.pushButton_password.setObjectName("pushButton_password")

        self.card_Ui(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def card_Ui(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.account.setText(_translate("Form", "卡密："))
        self.interface1.setText(_translate("Form", "卡密填写"))
        self.pushButton_password.setText(_translate("Form", "进入"))

    def text(self):
        type_card = self.account_edit.text()  # 读取输入框中的内容
        url = f"https://360stop.org/feature/pack/verify?api_version=1&app_id=8e084bb020f17f4c0000242d50cf1ffd&app_version=2.3&device_code=32b0ec73-4390-4ddd-8cfd-6502f7b1bb83&platform=2&secret={type_card}&version_code=23"
        resp = requests.get(url)
        resp_status = resp.json()['status']
        print(resp.json()['status'])
        login_true = resp.json()['result']['msg']
        if resp.json()['status'] == 0:
            messagebox.showinfo("提示", "卡密："+type_card+"\n"+"登录失败"+"\n"+login_true)
        elif resp.json()['status'] == 1:
            messagebox.showinfo("提示", "卡密："+type_card+"\n"+"登录成功"+"\n"+login_true)
            self.main_window = mains()
            self.main_window.show()
            MainWindow.hide()



if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = card()
    ui.setupUi(MainWindow)
    MainWindow.setWindowTitle('卡密验证')
    MainWindow.setWindowFlags(QtCore.Qt.WindowMinimizeButtonHint)
    MainWindow.show()
    sys.exit(app.exec_())