import sys
from PyQt5 import QtCore, QtGui, QtWidgets


class main(object):
    def setupUi(self, Form):
        Form.setObjectName("Form1")
        Form.resize(761, 476)
        self.pushButton = QtWidgets.QPushButton(Form)
        self.pushButton.setGeometry(QtCore.QRect(300, 240, 191, 81))
        self.pushButton.setObjectName("pushButton")
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(310, 50, 161, 91))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setObjectName("label")

        self.main_Ui(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def main_Ui(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton.setText(_translate("Form", "PushButton"))
        self.label.setText(_translate("Form", "登陆成功"))


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = main()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

